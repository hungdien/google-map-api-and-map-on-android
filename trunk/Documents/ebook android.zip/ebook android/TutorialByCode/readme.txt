http://insanitydesign.com/wp/projects/nehe-android-ports/
http://nehe.gamedev.net/